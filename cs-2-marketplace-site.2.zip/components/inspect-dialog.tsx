"use client"

import { CheckCircle2, Heart } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { useMarket } from "@/components/market-provider"
import { type Skin, formatPrice } from "@/lib/skins"
import { cn } from "@/lib/utils"
import { useI18n } from "@/lib/i18n"

export function InspectDialog({
  skin,
  onClose,
}: {
  skin: Skin | null
  onClose: () => void
}) {
  const { addToCart, toggleWishlist, isWished } = useMarket()
  const { t } = useI18n()
  const wished = skin ? isWished(skin.id) : false

  return (
    <Dialog open={!!skin} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="border-border bg-card sm:max-w-lg">
        {skin && (
          <>
            <DialogHeader>
              <DialogTitle className="text-xl font-bold text-foreground">
                {skin.isST ? "StatTrak™ " : ""}
                {skin.type} | {skin.title}
              </DialogTitle>
              <DialogDescription className="text-xs uppercase tracking-wide">
                {t(`exterior.${skin.exterior}`)} • {t("inspect.popularity", { n: skin.popularity })}
              </DialogDescription>
            </DialogHeader>

            <div className="my-2 flex h-44 items-center justify-center rounded-lg bg-[radial-gradient(circle,rgba(56,189,248,0.08)_0%,transparent_70%)]">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={skin.img || "/placeholder.svg"}
                alt={`${skin.type} | ${skin.title}`}
                className="max-h-full max-w-[80%] object-contain drop-shadow-[0_8px_24px_rgba(0,0,0,0.6)]"
                crossOrigin="anonymous"
              />
            </div>

            <div className="space-y-2.5 rounded-lg border border-border bg-input p-4 text-sm">
              <Row label={t("inspect.floatValue")}>
                <span className="font-bold text-primary">{skin.float.toFixed(4)}</span>
              </Row>
              <Row label={t("inspect.discountRate")}>
                <span className="font-bold text-success">{t("inspect.off", { n: skin.discount })}</span>
              </Row>
              <Row label={t("inspect.listPrice")}>
                <span className="text-muted-foreground line-through">{formatPrice(skin.oldPrice)}</span>
              </Row>
              <Row label={t("inspect.yourPrice")}>
                <span className="font-bold text-success">{formatPrice(skin.price)}</span>
              </Row>
              <Row label={t("inspect.delivery")}>
                <span className="flex items-center gap-1 font-bold text-success">
                  <CheckCircle2 className="h-4 w-4" /> {t("inspect.tradeable")}
                </span>
              </Row>
            </div>

            <div className="mt-2 flex gap-2">
              <Button
                onClick={() => {
                  addToCart(skin)
                  onClose()
                }}
                className="h-12 flex-1 bg-primary text-sm font-bold uppercase tracking-wide text-primary-foreground hover:bg-primary/90"
              >
                {t("inspect.lockAdd")}
              </Button>
              <Button
                variant="outline"
                onClick={() => toggleWishlist(skin)}
                aria-label={t("card.toggleWishlist")}
                className={cn(
                  "h-12 w-12 border-border bg-input p-0",
                  wished ? "border-favorite" : "hover:border-favorite",
                )}
              >
                <Heart className={cn("h-5 w-5", wished ? "fill-favorite text-favorite" : "text-muted-foreground")} />
              </Button>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  )
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-muted-foreground">{label}</span>
      {children}
    </div>
  )
}
