"use client"

import { createContext, useCallback, useContext, useMemo, useState } from "react"
import { toast } from "sonner"
import type { Skin } from "@/lib/skins"
import { formatPrice } from "@/lib/skins"
import { useI18n } from "@/lib/i18n"

interface MarketContextValue {
  cart: Skin[]
  wishlist: number[]
  wallet: number
  cartTotal: number
  addToCart: (skin: Skin) => void
  removeFromCart: (id: number) => void
  clearCart: () => void
  toggleWishlist: (skin: Skin) => void
  isInCart: (id: number) => boolean
  isWished: (id: number) => boolean
  deposit: (amount: number) => void
  checkout: () => void
  isLoggedIn: boolean
  login: () => void
  logout: () => void
}

const MarketContext = createContext<MarketContextValue | null>(null)

export function MarketProvider({ children }: { children: React.ReactNode }) {
  const { t } = useI18n()
  const [cart, setCart] = useState<Skin[]>([])
  const [wishlist, setWishlist] = useState<number[]>([])
  const [wallet, setWallet] = useState(412.8)
  const [isLoggedIn, setIsLoggedIn] = useState(true)

  const login = useCallback(() => {
    setIsLoggedIn(true)
    toast.success(t("toast.login.title"), { description: t("toast.login.desc") })
  }, [t])

  const logout = useCallback(() => {
    setIsLoggedIn(false)
    toast.success(t("toast.logout.title"), { description: t("toast.logout.desc") })
  }, [t])

  const isInCart = useCallback((id: number) => cart.some((s) => s.id === id), [cart])
  const isWished = useCallback((id: number) => wishlist.includes(id), [wishlist])

  const addToCart = useCallback(
    (skin: Skin) => {
      setCart((prev) => {
        if (prev.some((s) => s.id === skin.id)) {
          toast.info(t("toast.alreadyInCart"), { description: `${skin.type} | ${skin.title}` })
          return prev
        }
        toast.success(t("toast.addedToCart"), {
          description: `${skin.type} | ${skin.title} — ${formatPrice(skin.price)}`,
        })
        return [...prev, skin]
      })
    },
    [t],
  )

  const removeFromCart = useCallback((id: number) => {
    setCart((prev) => prev.filter((s) => s.id !== id))
  }, [])

  const clearCart = useCallback(() => setCart([]), [])

  const toggleWishlist = useCallback(
    (skin: Skin) => {
      setWishlist((prev) => {
        if (prev.includes(skin.id)) {
          return prev.filter((x) => x !== skin.id)
        }
        toast.success(t("toast.addedToWishlist"), { description: `${skin.type} | ${skin.title}` })
        return [...prev, skin.id]
      })
    },
    [t],
  )

  const deposit = useCallback(
    (amount: number) => {
      setWallet((prev) => prev + amount)
      toast.success(t("toast.depositSuccess"), {
        description: t("toast.depositDesc", { amount: formatPrice(amount) }),
      })
    },
    [t],
  )

  const cartTotal = useMemo(() => cart.reduce((sum, s) => sum + s.price, 0), [cart])

  const checkout = useCallback(() => {
    if (cart.length === 0) {
      toast.error(t("toast.cartEmpty"))
      return
    }
    if (cartTotal > wallet) {
      toast.error(t("toast.insufficientTitle"), {
        description: t("toast.insufficientDesc", { amount: formatPrice(cartTotal - wallet) }),
      })
      return
    }
    setWallet((prev) => prev - cartTotal)
    toast.success(t("toast.purchaseTitle"), {
      description: t("toast.purchaseDesc", { n: cart.length }),
    })
    setCart([])
  }, [cart, cartTotal, wallet, t])

  const value = useMemo(
    () => ({
      cart,
      wishlist,
      wallet,
      cartTotal,
      addToCart,
      removeFromCart,
      clearCart,
      toggleWishlist,
      isInCart,
      isWished,
      deposit,
      checkout,
      isLoggedIn,
      login,
      logout,
    }),
    [
      cart,
      wishlist,
      wallet,
      cartTotal,
      addToCart,
      removeFromCart,
      clearCart,
      toggleWishlist,
      isInCart,
      isWished,
      deposit,
      checkout,
      isLoggedIn,
      login,
      logout,
    ],
  )

  return <MarketContext.Provider value={value}>{children}</MarketContext.Provider>
}

export function useMarket() {
  const ctx = useContext(MarketContext)
  if (!ctx) throw new Error("useMarket must be used within MarketProvider")
  return ctx
}
