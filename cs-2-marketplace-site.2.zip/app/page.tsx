import { I18nProvider } from "@/lib/i18n"
import { MarketProvider } from "@/components/market-provider"
import { Marketplace } from "@/components/marketplace"

export default function Home() {
  return (
    <I18nProvider>
      <MarketProvider>
        <Marketplace />
      </MarketProvider>
    </I18nProvider>
  )
}
